// Animated Counters
function animateCounter(id, target, duration){
    let count = 0;
    const increment = target/(duration/20);
    const obj = document.getElementById(id);
    const timer = setInterval(()=>{
        count += increment;
        if(count >= target){ count = target; clearInterval(timer);}
        obj.innerText = Math.floor(count);
    },20);
}
animateCounter('completed', 26, 1500);
animateCounter('inprogress', 12, 1500);
