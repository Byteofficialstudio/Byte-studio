// Scroll Animations
const sections = document.querySelectorAll('.section');
window.addEventListener('scroll', ()=>{
  const triggerBottom = window.innerHeight / 5 * 4;
  sections.forEach(section=>{
    const sectionTop = section.getBoundingClientRect().top;
    if(sectionTop < triggerBottom){
      section.style.opacity = 1;
      section.style.transform = 'translateY(0)';
      section.style.transition = '0.8s ease-out';
    } else {
      section.style.opacity = 0;
      section.style.transform = 'translateY(40px)';
    }
  });
});

// Floating Mascot Interaction
const mascot = document.querySelector('.mascot');
document.addEventListener('mousemove', e=>{
    const x = e.clientX;
    const y = e.clientY;
    const rect = mascot.getBoundingClientRect();
    const dx = (x - (rect.left + rect.width/2))/40;
    const dy = (y - (rect.top + rect.height/2))/40;
    mascot.style.transform = `translate(${dx}px, ${dy}px)`;
});

// Cursor Neon Trail
const trail = document.querySelector('.cursor-trail');
document.addEventListener('mousemove', e=>{
  trail.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
});
